<?php
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
$host = trim($_SERVER['HTTP_HOST']);
$path = ltrim($_SERVER['REQUEST_URI'], '/');
$domain = "$protocol$host$path";
?>

<!doctype html>
<html ⚡ lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="format-detection" content="telephone=no">
      <title>BenihTOTO : Platform Hiburan No #1 Pay4d Deposit 5.000</title>
      <meta name="title" content="BenihTOTO : Platform Hiburan No #1 Pay4d Deposit 5.000">
      <meta name="description" content="BenihTOTO adalah Platform hiburan Pay4d terbaik dengan deposit mulai 5.000. Nikmati permainan seru, peluang menang yang besar, dan terpercaya setiap hari!" />
      <meta name="author" content="BenihTOTO">
      <meta name="og:type" content="website" />
      <meta name="og:title" content="BenihTOTO : Platform Hiburan No #1 Pay4d Deposit 5.000">
      <meta name="og:description" content="Beni4d adalah Platform hiburan Pay4d terbaik dengan deposit mulai 5.000. Nikmati permainan seru, peluang menang yang besar, dan terpercaya setiap hari!">
      <meta name="og:url" content="<?php echo $domain; ?>/">
      <meta name="og:site_name" content="BenihTOTO">
      <meta content="BenihTOTO : Platform Hiburan No #1 Pay4d Deposit 5.000" property="og:title">
      <meta content="BenihTOTO adalah Platform hiburan Pay4d terbaik dengan deposit mulai 5.000. Nikmati permainan seru, peluang menang yang besar, dan terpercaya setiap hari!" property="og:description">
      <meta name="og:image" content="/img/mobile-1.jpg">
      <meta name="twitter:card" content="summary_large_image">
      <link rel="canonical" href="<?php echo $domain; ?>/" />
      <link rel="icon" href="<?php echo $domain; ?>/img/Favicon.png" rel="icon" sizes="32x32" type="image/png" />
      <script src="https://cdn.ampproject.org/v0/amp-mustache-0.2.js" async="" custom-template="amp-mustache" nonce="MTMxNzM2NjIyNiwxOTg4MzMxNDg3"></script>
      <script src="https://cdn.ampproject.org/v0/amp-form-0.1.js" async="" custom-element="amp-form" nonce="MTMxNzM2NjIyNiwxOTg4MzMxNDg3"></script>
      <script src="https://cdn.ampproject.org/v0/amp-anim-0.1.js" async="" custom-element="amp-anim" nonce="MTMxNzM2NjIyNiwxOTg4MzMxNDg3"></script>
      <style amp-boilerplate>
         body {
         -webkit-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
         -moz-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
         -ms-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
         animation: -amp-start 8s steps(1, end) 0s 1 normal both
         }
         @-webkit-keyframes -amp-start {
         from {
         visibility: hidden
         }
         to {
         visibility: visible
         }
         }
         @-moz-keyframes -amp-start {
         from {
         visibility: hidden
         }
         to {
         visibility: visible
         }
         }
         @-ms-keyframes -amp-start {
         from {
         visibility: hidden
         }
         to {
         visibility: visible
         }
         }
         @-o-keyframes -amp-start {
         from {
         visibility: hidden
         }
         to {
         visibility: visible
         }
         }
         @keyframes -amp-start {
         from {
         visibility: hidden
         }
         to {
         visibility: visible
         }
         }
      </style>
      <noscript>
         <style amp-boilerplate>
            body {
            -webkit-animation: none;
            -moz-animation: none;
            -ms-animation: none;
            animation: none
            }
         </style>
      </noscript>
      <script async custom-element="amp-carousel" src="https://cdn.ampproject.org/v0/amp-carousel-0.2.js"></script>
      <script async src="https://cdn.ampproject.org/v0.js"></script>
      <style amp-custom>
         @font-face {
         font-family: Abel;
         font-style: normal;
         font-weight: 400;
         src: url(https://fonts.gstatic.com/s/abel/v11/MwQ5bhbm2POE2V9BPrcVGA.woff2) format('woff2')
         }
         @font-face {
         font-family: Oswald;
         font-style: normal;
         font-weight: 400;
         src: url(https://fonts.gstatic.com/s/oswald/v36/TK3iWkUHHAIjg752GT8G.woff2) format('woff2')
         }
         @font-face {
         font-family: Ubuntu;
         font-style: normal;
         font-weight: 400;
         src: url(https://fonts.gstatic.com/s/ubuntu/v20/4iCp6KVjbNBYlgoCjC3jvWyNL4U.woff2) format('woff2')
         }
         @font-face {
         font-family: Ubuntu;
         font-style: normal;
         font-weight: 500;
         src: url(https://fonts.gstatic.com/s/ubuntu/v20/4iCp6KVjbNBYlgoCjC3jvWyNL4U.woff2) format('woff2')
         }
         @font-face {
         font-family: Ubuntu;
         font-style: normal;
         font-weight: 700;
         src: url(https://fonts.gstatic.com/s/ubuntu/v20/4iCp6KVjbNBYlgoCjC3jvWyNL4U.woff2) format('woff2')
         }
         body {
         font-family: Abel, sans-serif
         }
         h1 {
         font-family: Oswald, sans-serif
         }
         p {
         font-family: Ubuntu, sans-serif
         }
         .container {
         width: 100%;
         padding-right: 15px;
         padding-left: 15px;
         margin-right: auto;
         margin-left: auto
         }
         @media (min-width:576px) {
         .container {
         max-width: 540px
         }
         }
         @media (min-width:768px) {
         .container {
         max-width: 720px
         }
         }
         @media (min-width:992px) {
         .container {
         max-width: 960px
         }
         }
         @media (min-width:1160px) {
         .container {
         max-width: 1100px
         }
         }
         .container-fluid {
         width: 100%;
         padding-right: 15px;
         padding-left: 15px;
         margin-right: auto;
         margin-left: auto
         }
         .row {
         display: -webkit-box;
         display: -ms-flexbox;
         display: flex;
         -ms-flex-wrap: wrap;
         flex-wrap: wrap;
         margin-right: -15px;
         margin-left: -15px
         }
         .no-gutters {
         margin-right: 0;
         margin-left: 0
         }
         .no-gutters>.col,
         .no-gutters>[class*=col-] {
         padding-right: 0;
         padding-left: 0
         }
         .col,
         .col-1,
         .col-10,
         .col-11,
         .col-12,
         .col-2,
         .col-3,
         .col-4,
         .col-5,
         .col-6,
         .col-7,
         .col-8,
         .col-9,
         .col-auto,
         .col-lg,
         .col-lg-1,
         .col-lg-10,
         .col-lg-11,
         .col-lg-12,
         .col-lg-2,
         .col-lg-3,
         .col-lg-4,
         .col-lg-5,
         .col-lg-6,
         .col-lg-7,
         .col-lg-8,
         .col-lg-9,
         .col-lg-auto,
         .col-md,
         .col-md-1,
         .col-md-10,
         .col-md-11,
         .col-md-12,
         .col-md-2,
         .col-md-3,
         .col-md-4,
         .col-md-5,
         .col-md-6,
         .col-md-7,
         .col-md-8,
         .col-md-9,
         .col-md-auto,
         .col-sm,
         .col-sm-1,
         .col-sm-10,
         .col-sm-11,
         .col-sm-12,
         .col-sm-2,
         .col-sm-3,
         .col-sm-4,
         .col-sm-5,
         .col-sm-6,
         .col-sm-7,
         .col-sm-8,
         .col-sm-9,
         .col-sm-auto,
         .col-xl,
         .col-xl-1,
         .col-xl-10,
         .col-xl-11,
         .col-xl-12,
         .col-xl-2,
         .col-xl-3,
         .col-xl-4,
         .col-xl-5,
         .col-xl-6,
         .col-xl-7,
         .col-xl-8,
         .col-xl-9,
         .col-xl-auto {
         position: relative;
         width: 100%;
         padding-right: 15px;
         padding-left: 15px
         }
         .col {
         -ms-flex-preferred-size: 0;
         flex-basis: 0;
         -webkit-box-flex: 1;
         -ms-flex-positive: 1;
         flex-grow: 1;
         max-width: 100%
         }
         .col-auto {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 auto;
         flex: 0 0 auto;
         width: auto;
         max-width: 100%
         }
         .col-1 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 8.33333%;
         flex: 0 0 8.33333%;
         max-width: 8.33333%
         }
         .col-2 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 16.66667%;
         flex: 0 0 16.66667%;
         max-width: 16.66667%
         }
         .col-3 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 25%;
         flex: 0 0 25%;
         max-width: 25%
         }
         .col-4 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 33.33333%;
         flex: 0 0 33.33333%;
         max-width: 33.33333%
         }
         .col-5 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 41.66667%;
         flex: 0 0 41.66667%;
         max-width: 41.66667%
         }
         .col-6 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 50%;
         flex: 0 0 50%;
         max-width: 50%
         }
         .col-7 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 58.33333%;
         flex: 0 0 58.33333%;
         max-width: 58.33333%
         }
         .col-8 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 66.66667%;
         flex: 0 0 66.66667%;
         max-width: 66.66667%
         }
         .col-9 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 75%;
         flex: 0 0 75%;
         max-width: 75%
         }
         .col-10 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 83.33333%;
         flex: 0 0 83.33333%;
         max-width: 83.33333%
         }
         .col-11 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 91.66667%;
         flex: 0 0 91.66667%;
         max-width: 91.66667%
         }
         .col-12 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 100%;
         flex: 0 0 100%;
         max-width: 100%
         }
         @media (min-width:576px) {
         .col-sm {
         -ms-flex-preferred-size: 0;
         flex-basis: 0;
         -webkit-box-flex: 1;
         -ms-flex-positive: 1;
         flex-grow: 1;
         max-width: 100%
         }
         .col-sm-auto {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 auto;
         flex: 0 0 auto;
         width: auto;
         max-width: 100%
         }
         .col-sm-1 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 8.33333%;
         flex: 0 0 8.33333%;
         max-width: 8.33333%
         }
         .col-sm-2 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 16.66667%;
         flex: 0 0 16.66667%;
         max-width: 16.66667%
         }
         .col-sm-3 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 25%;
         flex: 0 0 25%;
         max-width: 25%
         }
         .col-sm-4 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 33.33333%;
         flex: 0 0 33.33333%;
         max-width: 33.33333%
         }
         .col-sm-5 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 41.66667%;
         flex: 0 0 41.66667%;
         max-width: 41.66667%
         }
         .col-sm-6 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 50%;
         flex: 0 0 50%;
         max-width: 50%
         }
         .col-sm-7 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 58.33333%;
         flex: 0 0 58.33333%;
         max-width: 58.33333%
         }
         .col-sm-8 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 66.66667%;
         flex: 0 0 66.66667%;
         max-width: 66.66667%
         }
         .col-sm-9 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 75%;
         flex: 0 0 75%;
         max-width: 75%
         }
         .col-sm-10 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 83.33333%;
         flex: 0 0 83.33333%;
         max-width: 83.33333%
         }
         .col-sm-11 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 91.66667%;
         flex: 0 0 91.66667%;
         max-width: 91.66667%
         }
         .col-sm-12 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 100%;
         flex: 0 0 100%;
         max-width: 100%
         }
         }
         @media (min-width:768px) {
         .col-md {
         -ms-flex-preferred-size: 0;
         flex-basis: 0;
         -webkit-box-flex: 1;
         -ms-flex-positive: 1;
         flex-grow: 1;
         max-width: 100%
         }
         .col-md-auto {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 auto;
         flex: 0 0 auto;
         width: auto;
         max-width: 100%
         }
         .col-md-1 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 8.33333%;
         flex: 0 0 8.33333%;
         max-width: 8.33333%
         }
         .col-md-2 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 16.66667%;
         flex: 0 0 16.66667%;
         max-width: 16.66667%
         }
         .col-md-3 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 25%;
         flex: 0 0 25%;
         max-width: 25%
         }
         .col-md-4 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 33.33333%;
         flex: 0 0 33.33333%;
         max-width: 33.33333%
         }
         .col-md-5 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 41.66667%;
         flex: 0 0 41.66667%;
         max-width: 41.66667%
         }
         .col-md-6 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 50%;
         flex: 0 0 50%;
         max-width: 50%
         }
         .col-md-7 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 58.33333%;
         flex: 0 0 58.33333%;
         max-width: 58.33333%
         }
         .col-md-8 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 66.66667%;
         flex: 0 0 66.66667%;
         max-width: 66.66667%
         }
         .col-md-9 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 75%;
         flex: 0 0 75%;
         max-width: 75%
         }
         .col-md-10 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 83.33333%;
         flex: 0 0 83.33333%;
         max-width: 83.33333%
         }
         .col-md-11 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 91.66667%;
         flex: 0 0 91.66667%;
         max-width: 91.66667%
         }
         .col-md-12 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 100%;
         flex: 0 0 100%;
         max-width: 100%
         }
         .order-md-first {
         -webkit-box-ordinal-group: 0;
         -ms-flex-order: -1;
         order: -1
         }
         .order-md-last {
         -webkit-box-ordinal-group: 14;
         -ms-flex-order: 13;
         order: 13
         }
         .order-md-0 {
         -webkit-box-ordinal-group: 1;
         -ms-flex-order: 0;
         order: 0
         }
         .order-md-1 {
         -webkit-box-ordinal-group: 2;
         -ms-flex-order: 1;
         order: 1
         }
         .order-md-2 {
         -webkit-box-ordinal-group: 3;
         -ms-flex-order: 2;
         order: 2
         }
         .order-md-3 {
         -webkit-box-ordinal-group: 4;
         -ms-flex-order: 3;
         order: 3
         }
         .order-md-4 {
         -webkit-box-ordinal-group: 5;
         -ms-flex-order: 4;
         order: 4
         }
         .order-md-5 {
         -webkit-box-ordinal-group: 6;
         -ms-flex-order: 5;
         order: 5
         }
         .order-md-6 {
         -webkit-box-ordinal-group: 7;
         -ms-flex-order: 6;
         order: 6
         }
         .order-md-7 {
         -webkit-box-ordinal-group: 8;
         -ms-flex-order: 7;
         order: 7
         }
         .order-md-8 {
         -webkit-box-ordinal-group: 9;
         -ms-flex-order: 8;
         order: 8
         }
         .order-md-9 {
         -webkit-box-ordinal-group: 10;
         -ms-flex-order: 9;
         order: 9
         }
         .order-md-10 {
         -webkit-box-ordinal-group: 11;
         -ms-flex-order: 10;
         order: 10
         }
         .order-md-11 {
         -webkit-box-ordinal-group: 12;
         -ms-flex-order: 11;
         order: 11
         }
         .order-md-12 {
         -webkit-box-ordinal-group: 13;
         -ms-flex-order: 12;
         order: 12
         }
         .offset-md-0 {
         margin-left: 0
         }
         .offset-md-1 {
         margin-left: 8.33333%
         }
         .offset-md-2 {
         margin-left: 16.66667%
         }
         .offset-md-3 {
         margin-left: 25%
         }
         .offset-md-4 {
         margin-left: 33.33333%
         }
         .offset-md-5 {
         margin-left: 41.66667%
         }
         .offset-md-6 {
         margin-left: 50%
         }
         .offset-md-7 {
         margin-left: 58.33333%
         }
         .offset-md-8 {
         margin-left: 66.66667%
         }
         .offset-md-9 {
         margin-left: 75%
         }
         .offset-md-10 {
         margin-left: 83.33333%
         }
         .offset-md-11 {
         margin-left: 91.66667%
         }
         }
         @media (min-width:992px) {
         .col-lg {
         -ms-flex-preferred-size: 0;
         flex-basis: 0;
         -webkit-box-flex: 1;
         -ms-flex-positive: 1;
         flex-grow: 1;
         max-width: 100%
         }
         .col-lg-auto {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 auto;
         flex: 0 0 auto;
         width: auto;
         max-width: 100%
         }
         .col-lg-1 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 8.33333%;
         flex: 0 0 8.33333%;
         max-width: 8.33333%
         }
         .col-lg-2 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 16.66667%;
         flex: 0 0 16.66667%;
         max-width: 16.66667%
         }
         .col-lg-3 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 25%;
         flex: 0 0 25%;
         max-width: 25%
         }
         .col-lg-4 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 33.33333%;
         flex: 0 0 33.33333%;
         max-width: 33.33333%
         }
         .col-lg-5 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 41.66667%;
         flex: 0 0 41.66667%;
         max-width: 41.66667%
         }
         .col-lg-6 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 50%;
         flex: 0 0 50%;
         max-width: 50%
         }
         .col-lg-7 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 58.33333%;
         flex: 0 0 58.33333%;
         max-width: 58.33333%
         }
         .col-lg-8 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 66.66667%;
         flex: 0 0 66.66667%;
         max-width: 66.66667%
         }
         .col-lg-9 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 75%;
         flex: 0 0 75%;
         max-width: 75%
         }
         .col-lg-10 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 83.33333%;
         flex: 0 0 83.33333%;
         max-width: 83.33333%
         }
         .col-lg-11 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 91.66667%;
         flex: 0 0 91.66667%;
         max-width: 91.66667%
         }
         .col-lg-12 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 100%;
         flex: 0 0 100%;
         max-width: 100%
         }
         .order-lg-first {
         -webkit-box-ordinal-group: 0;
         -ms-flex-order: -1;
         order: -1
         }
         .order-lg-last {
         -webkit-box-ordinal-group: 14;
         -ms-flex-order: 13;
         order: 13
         }
         .order-lg-0 {
         -webkit-box-ordinal-group: 1;
         -ms-flex-order: 0;
         order: 0
         }
         .order-lg-1 {
         -webkit-box-ordinal-group: 2;
         -ms-flex-order: 1;
         order: 1
         }
         .order-lg-2 {
         -webkit-box-ordinal-group: 3;
         -ms-flex-order: 2;
         order: 2
         }
         .order-lg-3 {
         -webkit-box-ordinal-group: 4;
         -ms-flex-order: 3;
         order: 3
         }
         .order-lg-4 {
         -webkit-box-ordinal-group: 5;
         -ms-flex-order: 4;
         order: 4
         }
         .order-lg-5 {
         -webkit-box-ordinal-group: 6;
         -ms-flex-order: 5;
         order: 5
         }
         .order-lg-6 {
         -webkit-box-ordinal-group: 7;
         -ms-flex-order: 6;
         order: 6
         }
         .order-lg-7 {
         -webkit-box-ordinal-group: 8;
         -ms-flex-order: 7;
         order: 7
         }
         .order-lg-8 {
         -webkit-box-ordinal-group: 9;
         -ms-flex-order: 8;
         order: 8
         }
         .order-lg-9 {
         -webkit-box-ordinal-group: 10;
         -ms-flex-order: 9;
         order: 9
         }
         .order-lg-10 {
         -webkit-box-ordinal-group: 11;
         -ms-flex-order: 10;
         order: 10
         }
         .order-lg-11 {
         -webkit-box-ordinal-group: 12;
         -ms-flex-order: 11;
         order: 11
         }
         .order-lg-12 {
         -webkit-box-ordinal-group: 13;
         -ms-flex-order: 12;
         order: 12
         }
         .offset-lg-0 {
         margin-left: 0
         }
         .offset-lg-1 {
         margin-left: 8.33333%
         }
         .offset-lg-2 {
         margin-left: 16.66667%
         }
         .offset-lg-3 {
         margin-left: 25%
         }
         .offset-lg-4 {
         margin-left: 33.33333%
         }
         .offset-lg-5 {
         margin-left: 41.66667%
         }
         .offset-lg-6 {
         margin-left: 50%
         }
         .offset-lg-7 {
         margin-left: 58.33333%
         }
         .offset-lg-8 {
         margin-left: 66.66667%
         }
         .offset-lg-9 {
         margin-left: 75%
         }
         .offset-lg-10 {
         margin-left: 83.33333%
         }
         .offset-lg-11 {
         margin-left: 91.66667%
         }
         }
         @media (min-width:1160px) {
         .col-xl {
         -ms-flex-preferred-size: 0;
         flex-basis: 0;
         -webkit-box-flex: 1;
         -ms-flex-positive: 1;
         flex-grow: 1;
         max-width: 100%
         }
         .col-xl-auto {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 auto;
         flex: 0 0 auto;
         width: auto;
         max-width: 100%
         }
         .col-xl-1 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 8.33333%;
         flex: 0 0 8.33333%;
         max-width: 8.33333%
         }
         .col-xl-2 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 16.66667%;
         flex: 0 0 16.66667%;
         max-width: 16.66667%
         }
         .col-xl-3 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 25%;
         flex: 0 0 25%;
         max-width: 25%
         }
         .col-xl-4 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 33.33333%;
         flex: 0 0 33.33333%;
         max-width: 33.33333%
         }
         .col-xl-5 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 41.66667%;
         flex: 0 0 41.66667%;
         max-width: 41.66667%
         }
         .col-xl-6 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 50%;
         flex: 0 0 50%;
         max-width: 50%
         }
         .col-xl-7 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 58.33333%;
         flex: 0 0 58.33333%;
         max-width: 58.33333%
         }
         .col-xl-8 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 66.66667%;
         flex: 0 0 66.66667%;
         max-width: 66.66667%
         }
         .col-xl-9 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 75%;
         flex: 0 0 75%;
         max-width: 75%
         }
         .col-xl-10 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 83.33333%;
         flex: 0 0 83.33333%;
         max-width: 83.33333%
         }
         .col-xl-11 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 91.66667%;
         flex: 0 0 91.66667%;
         max-width: 91.66667%
         }
         .col-xl-12 {
         -webkit-box-flex: 0;
         -ms-flex: 0 0 100%;
         flex: 0 0 100%;
         max-width: 100%
         }
         .order-xl-first {
         -webkit-box-ordinal-group: 0;
         -ms-flex-order: -1;
         order: -1
         }
         .order-xl-last {
         -webkit-box-ordinal-group: 14;
         -ms-flex-order: 13;
         order: 13
         }
         .order-xl-0 {
         -webkit-box-ordinal-group: 1;
         -ms-flex-order: 0;
         order: 0
         }
         .order-xl-1 {
         -webkit-box-ordinal-group: 2;
         -ms-flex-order: 1;
         order: 1
         }
         .order-xl-2 {
         -webkit-box-ordinal-group: 3;
         -ms-flex-order: 2;
         order: 2
         }
         .order-xl-3 {
         -webkit-box-ordinal-group: 4;
         -ms-flex-order: 3;
         order: 3
         }
         .order-xl-4 {
         -webkit-box-ordinal-group: 5;
         -ms-flex-order: 4;
         order: 4
         }
         .order-xl-5 {
         -webkit-box-ordinal-group: 6;
         -ms-flex-order: 5;
         order: 5
         }
         .order-xl-6 {
         -webkit-box-ordinal-group: 7;
         -ms-flex-order: 6;
         order: 6
         }
         .order-xl-7 {
         -webkit-box-ordinal-group: 8;
         -ms-flex-order: 7;
         order: 7
         }
         .order-xl-8 {
         -webkit-box-ordinal-group: 9;
         -ms-flex-order: 8;
         order: 8
         }
         .order-xl-9 {
         -webkit-box-ordinal-group: 10;
         -ms-flex-order: 9;
         order: 9
         }
         .order-xl-10 {
         -webkit-box-ordinal-group: 11;
         -ms-flex-order: 10;
         order: 10
         }
         .order-xl-11 {
         -webkit-box-ordinal-group: 12;
         -ms-flex-order: 11;
         order: 11
         }
         .order-xl-12 {
         -webkit-box-ordinal-group: 13;
         -ms-flex-order: 12;
         order: 12
         }
         .offset-xl-0 {
         margin-left: 0
         }
         .offset-xl-1 {
         margin-left: 8.33333%
         }
         .offset-xl-2 {
         margin-left: 16.66667%
         }
         .offset-xl-3 {
         margin-left: 25%
         }
         .offset-xl-4 {
         margin-left: 33.33333%
         }
         .offset-xl-5 {
         margin-left: 41.66667%
         }
         .offset-xl-6 {
         margin-left: 50%
         }
         .offset-xl-7 {
         margin-left: 58.33333%
         }
         .offset-xl-8 {
         margin-left: 66.66667%
         }
         .offset-xl-9 {
         margin-left: 75%
         }
         .offset-xl-10 {
         margin-left: 83.33333%
         }
         .offset-xl-11 {
         margin-left: 91.66667%
         }
         }
         .table {
         width: 100%;
         margin-bottom: 1rem;
         color: #212529
         }
         .table td,
         .table th {
         padding: .75rem;
         vertical-align: top;
         border-top: 1px solid #dee2e6
         }
         .table thead th {
         vertical-align: bottom;
         border-bottom: 2px solid #dee2e6
         }
         .table tbody+tbody {
         border-top: 2px solid #dee2e6
         }
         .table-sm td,
         .table-sm th {
         padding: .3rem
         }
         .table-bordered {
         border: 1px solid #dee2e6
         }
         .table-bordered td,
         .table-bordered th {
         border: 1px solid #dee2e6
         }
         .table-bordered thead td,
         .table-bordered thead th {
         border-bottom-width: 2px
         }
         .table-borderless tbody+tbody,
         .table-borderless td,
         .table-borderless th,
         .table-borderless thead th {
         border: 0
         }
         .table-striped tbody tr:nth-of-type(odd) {
         background-color: rgba(0, 0, 0, .05)
         }
         .table-hover tbody tr:hover {
         color: #212529;
         background-color: rgba(0, 0, 0, .075)
         }
         .table-primary,
         .table-primary>td,
         .table-primary>th {
         background-color: #fefad8
         }
         .table-primary tbody+tbody,
         .table-primary td,
         .table-primary th,
         .table-primary thead th {
         border-color: #fef5b6
         }
         .table-hover .table-primary:hover {
         background-color: #fdf7bf
         }
         .table-hover .table-primary:hover>td,
         .table-hover .table-primary:hover>th {
         background-color: #fdf7bf
         }
         .table-secondary,
         .table-secondary>td,
         .table-secondary>th {
         background-color: #d6d8db
         }
         .table-secondary tbody+tbody,
         .table-secondary td,
         .table-secondary th,
         .table-secondary thead th {
         border-color: #b3b7bb
         }
         .table-hover .table-secondary:hover {
         background-color: #c8cbcf
         }
         .table-hover .table-secondary:hover>td,
         .table-hover .table-secondary:hover>th {
         background-color: #c8cbcf
         }
         .table-success,
         .table-success>td,
         .table-success>th {
         background-color: #c3e6cb
         }
         .table-success tbody+tbody,
         .table-success td,
         .table-success th,
         .table-success thead th {
         border-color: #8fd19e
         }
         .table-hover .table-success:hover {
         background-color: #b1dfbb
         }
         .table-hover .table-success:hover>td,
         .table-hover .table-success:hover>th {
         background-color: #b1dfbb
         }
         .table-info,
         .table-info>td,
         .table-info>th {
         background-color: #bee5eb
         }
         .table-info tbody+tbody,
         .table-info td,
         .table-info th,
         .table-info thead th {
         border-color: #86cfda
         }
         .table-hover .table-info:hover {
         background-color: #abdde5
         }
         .table-hover .table-info:hover>td,
         .table-hover .table-info:hover>th {
         background-color: #abdde5
         }
         .table-warning,
         .table-warning>td,
         .table-warning>th {
         background-color: #ffeeba
         }
         .table-warning tbody+tbody,
         .table-warning td,
         .table-warning th,
         .table-warning thead th {
         border-color: #ffdf7e
         }
         .table-hover .table-warning:hover {
         background-color: #ffe8a1
         }
         .table-hover .table-warning:hover>td,
         .table-hover .table-warning:hover>th {
         background-color: #ffe8a1
         }
         .table-danger,
         .table-danger>td,
         .table-danger>th {
         background-color: #f5c6cb
         }
         .table-danger tbody+tbody,
         .table-danger td,
         .table-danger th,
         .table-danger thead th {
         border-color: #ed969e
         }
         .table-hover .table-danger:hover {
         background-color: #f1b0b7
         }
         .table-hover .table-danger:hover>td,
         .table-hover .table-danger:hover>th {
         background-color: #f1b0b7
         }
         .table-light,
         .table-light>td,
         .table-light>th {
         background-color: #fdfdfe
         }
         .table-light tbody+tbody,
         .table-light td,
         .table-light th,
         .table-light thead th {
         border-color: #fbfcfc
         }
         .table-hover .table-light:hover {
         background-color: #ececf6
         }
         .table-hover .table-light:hover>td,
         .table-hover .table-light:hover>th {
         background-color: #ececf6
         }
         .table-dark,
         .table-dark>td,
         .table-dark>th {
         background-color: #c6c8ca
         }
         .table-dark tbody+tbody,
         .table-dark td,
         .table-dark th,
         .table-dark thead th {
         border-color: #95999c
         }
         .table-hover .table-dark:hover {
         background-color: #b9bbbe
         }
         .table-hover .table-dark:hover>td,
         .table-hover .table-dark:hover>th {
         background-color: #b9bbbe
         }
         .table-active,
         .table-active>td,
         .table-active>th {
         background-color: rgba(0, 0, 0, .075)
         }
         .table-hover .table-active:hover {
         background-color: rgba(0, 0, 0, .075)
         }
         .table-hover .table-active:hover>td,
         .table-hover .table-active:hover>th {
         background-color: rgba(0, 0, 0, .075)
         }
         .table .thead-dark th {
         color: #fff;
         background-color: #343a40;
         border-color: #454d55
         }
         .table .thead-light th {
         color: #495057;
         background-color: #e9ecef;
         border-color: #dee2e6
         }
         .table-dark {
         color: #fff;
         background-color: #343a40
         }
         .table-dark td,
         .table-dark th,
         .table-dark thead th {
         border-color: #454d55
         }
         .table-dark.table-bordered {
         border: 0
         }
         .table-dark.table-striped tbody tr:nth-of-type(odd) {
         background-color: rgba(255, 255, 255, .05)
         }
         .table-dark.table-hover tbody tr:hover {
         color: #fff;
         background-color: rgba(255, 255, 255, .075)
         }
         @media (max-width:575.98px) {
         .table-responsive-sm {
         display: block;
         width: 100%;
         overflow-x: auto;
         -webkit-overflow-scrolling: touch
         }
         .table-responsive-sm>.table-bordered {
         border: 0
         }
         }
         @media (max-width:767.98px) {
         .table-responsive-md {
         display: block;
         width: 100%;
         overflow-x: auto;
         -webkit-overflow-scrolling: touch
         }
         .table-responsive-md>.table-bordered {
         border: 0
         }
         }
         @media (max-width:991.98px) {
         .table-responsive-lg {
         display: block;
         width: 100%;
         overflow-x: auto;
         -webkit-overflow-scrolling: touch
         }
         .table-responsive-lg>.table-bordered {
         border: 0
         }
         }
         @media (max-width:1159.98px) {
         .table-responsive-xl {
         display: block;
         width: 100%;
         overflow-x: auto;
         -webkit-overflow-scrolling: touch
         }
         .table-responsive-xl>.table-bordered {
         border: 0
         }
         }
         .table-responsive {
         display: block;
         width: 100%;
         overflow-x: auto;
         -webkit-overflow-scrolling: touch
         }
         .table-responsive>.table-bordered {
         border: 0
         }
         .media {
         display: -webkit-box;
         display: -ms-flexbox;
         display: flex;
         -webkit-box-align: start;
         -ms-flex-align: start;
         align-items: flex-start
         }
         .media-body {
         -webkit-box-flex: 1;
         -ms-flex: 1;
         flex: 1
         }
         .align-baseline {
         vertical-align: baseline
         }
         .align-top {
         vertical-align: top
         }
         .align-middle {
         vertical-align: middle
         }
         .align-bottom {
         vertical-align: bottom
         }
         .align-text-bottom {
         vertical-align: text-bottom
         }
         .align-text-top {
         vertical-align: text-top
         }
         .clearfix::after {
         display: block;
         clear: both;
         content: ""
         }
         .d-none {
         display: none
         }
         .d-inline {
         display: inline
         }
         .d-inline-block {
         display: inline-block
         }
         .d-block {
         display: block
         }
         .d-table {
         display: table
         }
         .d-table-row {
         display: table-row
         }
         .d-table-cell {
         display: table-cell
         }
         .d-flex {
         display: -webkit-box;
         display: -ms-flexbox;
         display: flex
         }
         .d-inline-flex {
         display: -webkit-inline-box;
         display: -ms-inline-flexbox;
         display: inline-flex
         }
         @media (min-width:576px) {
         .d-sm-none {
         display: none
         }
         .d-sm-inline {
         display: inline
         }
         .d-sm-inline-block {
         display: inline-block
         }
         .d-sm-block {
         display: block
         }
         .d-sm-table {
         display: table
         }
         .d-sm-table-row {
         display: table-row
         }
         .d-sm-table-cell {
         display: table-cell
         }
         .d-sm-flex {
         display: -webkit-box;
         display: -ms-flexbox;
         display: flex
         }
         .d-sm-inline-flex {
         display: -webkit-inline-box;
         display: -ms-inline-flexbox;
         display: inline-flex
         }
         }
         @media (min-width:768px) {
         .d-md-none {
         display: none
         }
         .d-md-inline {
         display: inline
         }
         .d-md-inline-block {
         display: inline-block
         }
         .d-md-block {
         display: block
         }
         .d-md-table {
         display: table
         }
         .d-md-table-row {
         display: table-row
         }
         .d-md-table-cell {
         display: table-cell
         }
         .d-md-flex {
         display: -webkit-box;
         display: -ms-flexbox;
         display: flex
         }
         .d-md-inline-flex {
         display: -webkit-inline-box;
         display: -ms-inline-flexbox;
         display: inline-flex
         }
         }
         @media (min-width:992px) {
         .d-lg-none {
         display: none
         }
         .d-lg-inline {
         display: inline
         }
         .d-lg-inline-block {
         display: inline-block
         }
         .d-lg-block {
         display: block
         }
         .d-lg-table {
         display: table
         }
         .d-lg-table-row {
         display: table-row
         }
         .d-lg-table-cell {
         display: table-cell
         }
         .d-lg-flex {
         display: -webkit-box;
         display: -ms-flexbox;
         display: flex
         }
         .d-lg-inline-flex {
         display: -webkit-inline-box;
         display: -ms-inline-flexbox;
         display: inline-flex
         }
         }
         @media (min-width:1160px) {
         .d-xl-none {
         display: none
         }
         .d-xl-inline {
         display: inline
         }
         .d-xl-inline-block {
         display: inline-block
         }
         .d-xl-block {
         display: block
         }
         .d-xl-table {
         display: table
         }
         .d-xl-table-row {
         display: table-row
         }
         .d-xl-table-cell {
         display: table-cell
         }
         .d-xl-flex {
         display: -webkit-box;
         display: -ms-flexbox;
         display: flex
         }
         .d-xl-inline-flex {
         display: -webkit-inline-box;
         display: -ms-inline-flexbox;
         display: inline-flex
         }
         }
         @media print {
         .d-print-none {
         display: none
         }
         .d-print-inline {
         display: inline
         }
         .d-print-inline-block {
         display: inline-block
         }
         .d-print-block {
         display: block
         }
         .d-print-table {
         display: table
         }
         .d-print-table-row {
         display: table-row
         }
         .d-print-table-cell {
         display: table-cell
         }
         .d-print-flex {
         display: -webkit-box;
         display: -ms-flexbox;
         display: flex
         }
         .d-print-inline-flex {
         display: -webkit-inline-box;
         display: -ms-inline-flexbox;
         display: inline-flex
         }
         }
         .embed-responsive {
         position: relative;
         display: block;
         width: 100%;
         padding: 0;
         overflow: hidden
         }
         .embed-responsive::before {
         display: block;
         content: ""
         }
         .embed-responsive .embed-responsive-item,
         .embed-responsive embed,
         .embed-responsive iframe,
         .embed-responsive object,
         .embed-responsive video {
         position: absolute;
         top: 0;
         bottom: 0;
         left: 0;
         width: 100%;
         height: 100%;
         border: 0
         }
         .visible {
         visibility: visible
         }
         .invisible {
         visibility: hidden
         }
         html {
         overflow: auto
         }
         body {
         overflow: hidden;
         margin: 0
         }
         a,
         a:hover {
         text-decoration: none
         }
         :focus {
         outline: 0;
         outline-color: none;
         outline-style: none;
         outline-width: 0
         }
         ul {
         -webkit-padding-start: 0;
         padding-inline-start: 0
         }
         ul li {
         list-style-type: none
         }
         .text-white {
         color: #fff
         }
         .text-gold {
         color: #ffbd2b
         }
         body {
         font-family: Helvetica, sans-serif
         }
         .sans-serif {
         font-family: Helvetica, sans-serif
         }
         .font-bold,
         strong {
         font-weight: 700
         }
         h1 {
         font-size: 40px
         }
         .text-h2,
         h2 {
         font-size: 36px
         }
         .text-h3,
         h3 {
         font-size: 24px
         }
         .text-h4,
         h4,
         p {
         font-size: 16px;
         word-spacing: 2px;
         line-height: 25px
         }
         .text-uppercase {
         text-transform: uppercase
         }
         .fontsize-70 {
         font-size: 70px
         }
         @media (max-width:991.98px) {
         h1 {
         font-size: 30px
         }
         .text-h2,
         h2 {
         font-size: 30px
         }
         .text-h3,
         h3 {
         font-size: 20px
         }
         .text-h4,
         h4,
         p {
         font-size: 15px
         }
         .fontsize-70 {
         font-size: 50px
         }
         }
         .btn-cta {
         background: #fff;
         background: -webkit-gradient(linear, left bottom, left top, from(#ffb42f), to(#fff));
         background: linear-gradient(0deg, #900 0, #fd0000 100%);
         font-size: 20px;
         font-weight: 700;
         text-transform: uppercase;
         color: #fff;
         padding: 13px 0
         }
         .btn-block {
         display: block;
         text-align: center
         }
         body {
         background: #131313;
         background: -webkit-gradient(linear, left top, right top, from(#131313), to(#232323));
         background: linear-gradient(90deg, #131313 0, #232323 100%)
         }
         @media (max-width:991.98px) {
         .the-main-container {
         padding: 0
         }
         }
         .main-body {
         background: #0a0801;
         color: #fff;
         overflow: hidden;
         position: relative;
         border-radius: 1px;
         box-shadow: rgb(0 0 0 / 42%) 0 0 10px 0
         }
         .main-body header {
         padding: 20px 40px 20px;
         background: #111
         }
         .main-body header .logo amp-img {
         height: 50px;
         width: 266px
         }
         @media (max-width:991.98px) {
         .main-body header .logo amp-img {
         max-width: 100%
         }
         }
         @media (max-width:991.98px) {
         .main-body header .logo {
         display: -webkit-box;
         display: -ms-flexbox;
         display: flex;
         -webkit-box-pack: center;
         -ms-flex-pack: center;
         justify-content: center;
         width: 100%
         }
         }
         .main-body header .main-nav .the-nav {
         margin: 0
         }
         .main-body header .main-nav .the-nav .nav-item {
         font-size: 16px;
         margin-right: 15px
         }
         .main-body header .main-nav .the-nav .nav-item a {
         color: #fff
         }
         .main-body header .main-nav .the-nav .nav-item:last-child {
         margin-right: 0
         }
         .main-body .featured-image amp-img {
         width: 100%;
         height: auto
         }
         .main-body .content-body {
         padding: 0 135px 5px
         }
         @media (max-width:991.98px) {
         .main-body .content-body {
         padding: 0 55px 5px
         }
         }
         .main-body .sectiontitle {
         font-size: 35px;
         line-height: 50px;
         font-weight: 700;
         position: relative;
         padding-bottom: 25px;
         margin-bottom: 20px
         }
         .main-body .sectiontitle:after {
         content: "";
         position: absolute;
         bottom: 0;
         left: 0;
         width: 100px;
         height: 5px;
         background: #fff
         }
         @media (min-width:768px) {
         .main-body p {
         text-align: justify
         }
         }
         .main-body .faq .que {
         background: #fff;
         background: -webkit-gradient(linear, left top, right top, from(#fff), to(#e8a938));
         background: linear-gradient(90deg, #171c46 0, #003864 100%);
         color: #fff;
         font-weight: 700;
         padding: 10px 10px 10px 15px
         }
         .main-body .faq .ans {
         padding: 10px 10px 10px 20px;
         border-left: 1px solid #fff;
         margin: 5px 5px 30px 10px
         }
         a {
         color: #fff
         }
         .responsive {
         width: 100%;
         height: auto
         }
         .the-list li {
         margin-bottom: 8px;
         list-style: disc;
         margin-inline-start: 16px
         }
         table {
         position: relative;
         overflow: hidden;
         width: 100%;
         max-width: 100%;
         color: #fff;
         text-align: center;
         background-color: #161616;
         border: 2px solid red;
         border-collapse: separate;
         border-radius: 12px
         }
         table.table-layout-fixed {
         table-layout: fixed
         }
         table.table-has-caption {
         border-top: none;
         border-top-left-radius: 0;
         border-top-right-radius: 0
         }
         table caption {
         padding: 15px;
         color: #fff;
         font-size: 14px;
         font-weight: 700;
         line-height: 24px;
         text-transform: uppercase;
         background-color: #000;
         border-top-left-radius: 12px;
         border-top-right-radius: 12px
         }
         table tr td,
         table tr th {
         padding: 10px;
         line-height: 24px;
         vertical-align: middle;
         border: 1px solid red;
         font-size: 12px
         }
         table thead tr th {
         background-color: gold;
         border-bottom: 2px solid red;
         color: #000;
         font-weight: 700;
         border-radius: 10px 10px 0 0
         }
         table tr:last-of-type:not(:first-of-type) td,
         table tr:last-of-type:not(:first-of-type) th {
         border-bottom: none
         }
         table tfoot tr td,
         table tfoot tr th {
         border: none
         }
         table tfoot tr:first-of-type td,
         table tfoot tr:first-of-type th {
         border-top: 2px solid #e6e9ee
         }
         table tr td .button,
         table tr td button,
         table tr th .highlight {
         color: #000;
         font-size: 20px;
         font-weight: 700
         }
         table tr .responsive-th {
         display: none;
         overflow: hidden;
         position: absolute;
         left: 4%;
         width: 44%;
         color: #000;
         font-size: 16px;
         text-overflow: ellipsis;
         text-align: right;
         white-space: nowrap
         }
         .button.button-secondary,
         button.button-secondary {
         color: #fff;
         background-color: #18214a
         }
         .button.button-primary,
         .button.button-secondary,
         button.button-primary,
         button.button-secondary {
         padding: 7px 22px;
         border-radius: 6px
         }
         .marquee {
         width: 100%;
         margin: 0 auto;
         white-space: nowrap;
         overflow: hidden;
         box-sizing: border-box;
         height: 24px;
         font-family: prompt, arial;
         text-transform: uppercase;
         font-size: 14px;
         font-style: bold;
         color: #ffff;
         margin-bottom: 0
         }
         .marquee span {
         display: inline-block;
         padding-left: 100%;
         text-indent: 0;
         animation: marquee 30s linear infinite
         }
         .marquee span:hover {
         animation-play-state: paused
         }
         @keyframes marquee {
         0% {
         transform: translate(0, 0)
         }
         100% {
         transform: translate(-100%, 0)
         }
         }
         p {
         text-align: justify
         }
         .submenu {
         color: #5db;
         margin: 0
         }
         .nomargin {
         margin: 0
         }
         .seo-content {
         font-size: .12.8em;
         color: #d3d3d3;
         text-align: justify;
         letter-spacing: .1px
         }
         .btn {
         display: grid;
         padding: 6px 12px;
         margin-bottom: 0;
         font-size: large;
         font-weight: 400;
         line-height: 1.42857143;
         text-align: center;
         white-space: nowrap;
         vertical-align: middle;
         -ms-touch-action: manipulation;
         touch-action: manipulation;
         cursor: pointer;
         -webkit-user-select: none;
         -moz-user-select: none;
         -ms-user-select: none;
         user-select: none;
         background-image: none;
         border: 1px solid transparent;
         border-radius: 4px
         }
         .btn:active:focus,
         .btn:focus {
         outline: 5px auto -webkit-focus-ring-color;
         outline-offset: -2px
         }
         .btn:focus,
         .btn:hover {
         color: #333;
         text-decoration: none
         }
         .btn:active {
         background-image: none;
         outline: 0;
         -webkit-box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125);
         box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125)
         }
         .menu a {
         display: inline-block;
         padding: 10px 20px;
         text-decoration: none;
         color: #fff;
         margin: 0;
         font-size: 18px
         }
         .menu {
         display: block;
         width: 100%;
         text-align: center;
         background: #df1300
         }
         .menu a:hover {
         color: gold
         }
         .menu a {
         display: block;
         font-size: 16px;
         border: 1px solid #fff
         }
         .tanggal {
         font-size: 20px
         }
         .btn-primary {
         color: #edebeb;
         font-weight: 700;
         text-decoration: none;
         text-transform: uppercase;
         border-color: #fff;
         background-color: #df1300
         }
         .btn-primary:focus {
         color: #fff;
         background-color: #2b2b2b;
         border-color: #df1300
         }
         .btn-primary:hover {
         color: #df1300;
         background-color: #2b2b2b;
         border-color: #df1300
         }
         .btn-primary:active {
         color: #fff;
         background-color: #2b2b2b;
         border-color: #2b2b2b
         }
         .btn-primary:active:focus,
         .btn-primary:active:hover {
         color: #fff;
         background-color: #2b2b2b;
         border-color: #df1300
         }
         .btn-primary:active {
         background-image: none
         }
         .container-global {
         max-width: 1000px;
         margin: 0 auto
         }
         html {
         scroll-behavior: smooth
         }
         a {
         text-decoration: none
         }
         body {
         background: #131313;
         background-size: cover;
         background-attachment: fixed;
         margin: 0;
         display: block
         }
         label {
         font-family: Raleway, sans-serif;
         font-size: 11pt
         }
         #forgot-pass {
         color: #2dbd6e;
         font-family: Raleway, sans-serif;
         font-size: 10pt;
         margin-top: 3px;
         text-align: right
         }
         #card {
         margin: -35px;
         margin-top: 10px;
         width: 100%;
         margin-left: 0
         }
         #card-content {
         padding: 0 5px;
         margin-bottom: -36px
         }
         #card-title {
         font-family: "Raleway Thin", sans-serif;
         letter-spacing: 4px;
         padding-bottom: 23px;
         padding-top: 15px;
         text-align: center;
         color: #fff
         }
         #signup {
         color: #2dbd6e;
         font-family: Raleway, sans-serif;
         font-size: 10pt;
         margin-top: 16px;
         text-align: center
         }
         #submit-btn {
         background: -webkit-linear-gradient(right, #a6f77b, #2dbd6e);
         border: none;
         border-radius: 21px;
         box-shadow: 0 1px 8px #24c64f;
         cursor: pointer;
         color: #fff;
         font-family: "Raleway SemiBold", sans-serif;
         height: 42.3px;
         margin: 0 auto;
         margin-top: 50px;
         transition: .25s;
         width: 153px
         }
         #submit-btn:hover {
         box-shadow: 0 1px 18px #24c64f
         }
         .form {
         align-items: left;
         display: flex;
         flex-direction: column
         }
         .form-border {
         background: -webkit-linear-gradient(right, #a6f77b, #2ec06f);
         height: 1px;
         width: 100%
         }
         .form-content {
         background: #fbfbfb;
         border: none;
         outline: 0;
         padding-top: 14px
         }
         .underline-title {
         background: -webkit-linear-gradient(right, #fff, #fff);
         height: 2px;
         margin: -1.1rem auto 0 auto;
         width: 100%
         }
         .contactField.contactOption,
         .contactField.requiredField {
         height: 35px;
         margin-bottom: 0;
         margin-left: -5px;
         width: 100%;
         text-align: center;
         color: #000;
         border: var(--bs-border-width) solid var(--bs-border-color);
         -webkit-appearance: none;
         -moz-appearance: none;
         appearance: none;
         border-radius: 25px
         }
         .form-group {
         clear: both;
         margin-bottom: 10px
         }
         .buttonjoin {
         width: 100%
         }
         .buttonWrap.button-green {
         display: block;
         font-size: 18px;
         text-align: center;
         margin-top: 11px;
         padding: 10px 26px;
         line-height: 20px;
         border: 1px solid #1f619b;
         color: #fff;
         border-width: 0;
         border-radius: 25px;
         letter-spacing: 2px;
         font-weight: bolder;
         text-transform: uppercase;
         color: var(--bs-btn-hover-color);
         background-color: #31d2f2;
         border-color: #25cff2;
         text-shadow: 1px 1px #000
         }
         .buttonWrap.button-blue {
         display: block;
         font-size: 18px;
         text-align: center;
         background: linear-gradient(to bottom, #4f0 0, #1c7a00 100%);
         margin-top: 0;
         border: 1px solid #1f619b;
         color: #fff;
         border-width: 0;
         border-radius: 25px;
         letter-spacing: 2px;
         font-weight: bolder;
         text-transform: uppercase;
         background-image: linear-gradient(#f17a77, #ee5f5b 60%, #ec4d49);
         background-repeat: no-repeat;
         filter: none;
         padding: 7px 16px;
         line-height: 1.3333333;
         text-shadow: 1px 1px #000
         }
         .underline {
         text-decoration: underline
         }
         .right {
         text-align: right
         }
         .left {
         float: left
         }
         .right {
         float: right
         }
         .note {
         font-size: 14px;
         color: #fff;
         margin-bottom: 20px;
         font-weight: 700
         }
         .center {
         text-align: center;
         margin-bottom: 10px
         }
         .center-bank {
         text-align: center;
         color: #fff;
         font-weight: 700;
         margin-left: -5px
         }
         .showp {
         color: #fff;
         display: flex;
         float: right
         }
         .bank {
         display: inline-block;
         background-color: #fff;
         padding: 3px 10px 5px 10px;
         width: 45%;
         margin: 5px 0 0 0;
         text-align: left;
         border-radius: 6px
         }
         .bank {
         border-radius: 10px;
         padding: 0;
         height: 32px;
         width: 45%;
         margin-left: 7px;
         border: groove 3px;
         display: inline-block;
         vertical-align: middle
         }
         .bank img:first-child {
         width: 65px;
         display: inline-block;
         vertical-align: middle;
         margin-left: auto;
         margin-right: 2px;
         margin-top: 6px;
         margin-bottom: auto
         }
         .bank img:last-child {
         width: 70px;
         display: inline-block;
         vertical-align: middle;
         margin-left: auto;
         margin-right: auto;
         margin-top: 4px
         }
         .margintop {
         margin-top: -20px
         }
         .nav {
         display: grid;
         grid-template-columns: 1fr 2fr 1fr;
         align-items: center
         }
         .logo {
         text-align: center;
         margin: auto;
         display: block;
         margin-top: 20px
         }
         .livechat {
         align-self: center
         }
         .buttonlc {
         position: absolute;
         top: 18px;
         right: 10px;
         width: 70px;
         font-size: 10px
         }
         .slc {
         top: 85px
         }
         .space {
         right: 54px;
         margin-top: -73px
         }
         .buttonWrap.buttonlc2.button-orange {
         display: inline-block;
         font-family: arial;
         padding: 15px 16px;
         line-height: 20px;
         border: 1px solid #fff;
         color: #000;
         border-width: 0;
         border-radius: 25px;
         font-weight: 700;
         font-size: 15px;
         text-align: center;
         text-shadow: 2px 1px 9px rgb(0 0 0 / 30%);
         margin-bottom: 10px;
         margin-top: 2px
         }
         .page-header {
         width: 100%;
         z-index: 999999;
         border-bottom: 2px solid #ffa500;
         top: 0;
         background-color: #0a0801
         }
         .shead {
         height: 75px
         }
         .buttonlc2 {
         text-align: center;
         width: 100%;
         height: 15px;
         color: #fff;
         padding: 10px 0 10px 0;
         display: inline-block;
         margin-bottom: 10px;
         font-family: aller;
         font-size: 14px;
         line-height: 12px
         }
         .main {
         background-color: #000
         }
         footer#footer {
         width: 1170px;
         margin: auto
         }
         @-webkit-keyframes change-color {
         0% {
         color: #000
         }
         50% {
         color: #fff
         }
         100% {
         color: #000
         }
         }
         @keyframes change-color {
         0% {
         color: #fff
         }
         50% {
         color: #fff
         }
         100% {
         color: #000
         }
         }
         .buttonWrap.buttondapk.button-blues.contactSubmitButton {
         padding: 10px 26px;
         line-height: 22px;
         box-shadow: inset 0 0 0 1px #daa520, inset 0 2px 0 0 #daa520, inset 0 4px 4px 2px #b8860b, 3px 3px 3px 1px rgb(0 0 0 / 20%);
         background-image: linear-gradient(to bottom, #b8860b 0, #b8860b 50%, gold 95%);
         border: 1px solid #ad0000;
         color: #fff;
         border-width: 0;
         border-radius: 20px;
         font-weight: 700;
         font-size: 18px;
         text-align: center;
         text-shadow: 2px 1px 9px rgb(0 0 0 / 70%);
         margin-bottom: 10px
         }
         .buttonWrap.button-biru2 {
         padding: 10px 26px;
         line-height: 22px;
         box-shadow: inset 0 0 0 1px #001d48, inset 0 2px 0 0 #001d48, inset 0 4px 4px 2px #004a97, 3px 3px 3px 1px rgb(0 0 0 / 20%);
         background-image: linear-gradient(to bottom, #00264c 0, #0042b7 50%, #007eff 100%);
         border: 1px solid #005aff;
         color: #fff;
         border-width: 0;
         border-radius: 20px;
         font-weight: 700;
         font-size: 18px;
         text-align: center;
         text-shadow: 2px 1px 9px rgb(0 0 0 / 70%);
         margin-bottom: 10px;
         height: 23px
         }
         .buttonWrap.buttondapk.button-reds.contactSubmitButton {
         padding: 10px 26px;
         min-width: 43%;
         line-height: 25px;
         box-shadow: inset 0 0 0 2px #fff, inset 0 2px 0 0 #7d7d7d, inset 0 4px 4px 2px #7d7d7d, 3px 3px 3px 1px rgb(0 0 0 / 20%);
         background-image: linear-gradient(to bottom, #ccc 0, #f9f9f9 50%, #e6e6e6 100%);
         border: 0 solid #000;
         color: #000;
         border-radius: 20px;
         font-weight: 700;
         font-size: 18px;
         text-align: center;
         height: 23px;
         margin-bottom: 10px
         }
         .contactSubmitButton {
         display: block;
         margin-right: 0
         }
         .buttondapk {
         text-align: center;
         margin-bottom: 10px;
         font-family: aller;
         font-size: 17px
         }
         .btn-anim {
         transition: all .5s;
         position: relative;
         overflow: hidden
         }
         #more {
         display: none
         }
         .footer {
         font-size: 12px;
         color: #868686
         }
         .center-text {
         color: #fff;
         text-align: center
         }
         .btn-primary {
         color: #fff;
         background-color: #b9882a;
         border: 3px #fad842 groove;
         border-radius: 0 23px 0 23px
         }
         .btn {
         display: inline-block;
         padding: 6px 12px;
         margin-bottom: 0;
         font-size: 14px;
         font-weight: 400
         }
         .keluaran {
         width: 99%;
         box-shadow: inset 0 0 0 0 #000, inset 0 50px 0 0 #f3f3f3, inset 0 0 0 3px #f3f3f3, 2px 2px 2px 1px rgb(35 35 35);
         background-image: #000;
         border-radius: 27px;
         border: groove
         }
         .keluaran th {
         color: #000;
         border-bottom: 2px solid #fff;
         font-size: large
         }
         .list-menu-mobile {
         width: 100%;
         margin-top: 10px
         }
         .list-menu-mobile a {
         width: 18%;
         padding: 0 1px;
         display: inline-block;
         margin: -21px 0
         }
         .list-menu-mobile a img {
         width: 100%
         }
         #livechat-BenihTOTO .guru {
         padding: 10px 26px;
         line-height: 22px;
         background-image: linear-gradient(to bottom, #fa9292 0, #890000 100%);
         border: 1px solid #fa9292;
         color: #fff;
         border-radius: 20px;
         font-weight: 600;
         font-size: 18px;
         text-align: center;
         text-shadow: 2px 1px 9px rgba(0, 0, 0, .7)
         }
         #livechat-BenihTOTO div.guru {
         background-image: linear-gradient(124deg, #717400, #746e00, #9b900a, #b9b10d, #9ea714, #f7ff0a, #a48a00, #d30d0d, #9f1919, #930b0b, #9d0505, #740000, #740000);
         color: #fff;
         text-shadow: 2px 1px 9px rgb(0 0 0 / 70%);
         background-size: 300% 300%;
         animation: background-gold 1s infinite;
         box-shadow: inset 0 -2px 0 gold;
         border: none
         }
         @keyframes background-gold {
         0% {
         background-position: 0 82%
         }
         50% {
         background-position: 100% 0
         }
         100% {
         background-position: 0 82%
         }
         }
         .banner {
         cursor: pointer;
         transition: all .3s ease;
         animation: borderPulse 1s infinite ease-out
         }
         @keyframes borderPulse {
         0% {
         filter: drop-shadow(0 0 2px #34e519)
         }
         50% {
         filter: drop-shadow(0 0 10px #34e519)
         }
         100% {
         filter: drop-shadow(0 0 2px #34e519)
         }
         }
         .banner:hover {
         animation: none;
         filter: brightness(1.5) drop-shadow(0 0 20px #34e519)
         }
         h1,
         h2,
         h3,
         li {
         color: gold
         }
         h3 {
         text-align: center;
         font-size: 15px;
         color: #fff
         }
         .aplikasi-BenihTOTO {
         background: linear-gradient(to bottom, #fe0 0, #e7c407 50%, #fdd700 100%);
         border: 1px solid #fff700;
         color: #000;
         font-weight: 500;
         box-shadow: none;
         margin: auto;
         padding: 12px 23px;
         text-align: center;
         border-radius: 119px
         }
         .aplikasi-BenihTOTO a {
         color: #000
         }
         .gif-dewi {
         margin-bottom: 20px
         }
         .iconuserlogin {
         position: absolute;
         left: 54px;
         background: #45474c;
         padding: 8px 10px;
         border-radius: 25px 0px 0px 25px;
         }
         .iconkeylogin {
         position: absolute;
         left: 54px;
         background: #43494f;
         border-radius: 5px 0 0 5px;
         padding: 8px 10px;
         border-radius: 25px 0px 0px 25px;
         }
         .bannerpay4d {
         margin: auto;
         padding: 50px 16px 0
         }
         .transaksi-list-bank {
         height: fit-content;
         display: grid;
         grid-template-columns: repeat(4, auto);
         grid-template-rows: repeat(4, auto);
         gap: 4px
         }
         .transaksi-header {
         height: 30px;
         border-radius: 5px;
         display: grid;
         place-items: center;
         font-weight: 700;
         border: 2px solid rgba(108, 108, 108, 1);
         background: rgba(54, 54, 54, 1);
         color: #fff
         }
         .transaksi-item {
         width: 100%
         }
         .fitur-header {
         text-align: center;
         color: #fff;
         font-size: 15px;
         font-family: Ubuntu, sans-serif;
         font-weight: 600
         }
         .my-navbar {
         height: 52px;
         padding: 0;
         max-width: 1100px;
         width: 100%;
         background: linear-gradient(0deg, rgba(0, 0, 0, 0.7) 0%, rgba(0, 0, 0, 0.6) 100%), #f9bb08;
         position: fixed;
         bottom: 0;
         color: #fff;
         z-index: 1100;
         display: flex;
         box-shadow: 0 -4px 3px rgba(0, 0, 0, .75)
         }
         .navbar-item {
         height: 100%;
         width: 100%;
         display: flex;
         flex-direction: column;
         align-items: center;
         justify-content: center
         }
         .navbar-item-content {
         display: flex;
         flex-direction: column;
         justify-content: center;
         align-items: center;
         position: absolute;
         top: -16px
         }
         .navbar-item-content>img {
         height: auto;
         width: 33px
         }
         .navbar-item-content>label {
         white-space: nowrap;
         margin-top: 4px;
         font-weight: 700;
         font-size: var(--text-size-default);
         color: #fff;
         font-size: 12px
         }
         @media only screen and (min-width:800px) {
         .iconuserlogin {
         position: absolute;
         left: 134px;
         background: #45474c;
         padding: 15px 20px;
         border-radius: 25px 0px 0px 25px;
         }
         .iconkeylogin {
         position: absolute;
         left: 134px;
         background: #43494f;
         border-radius: 5px 0 0 5px;
         padding: 15px 20px;
         border-radius: 25px 0px 0px 25px;
         }
         .contactField.contactOption,
         .contactField.requiredField {
         height: 50px;
         margin-bottom: 0;
         margin-left: -5px;
         width: 100%;
         text-align: center;
         color: #000;
         border: var(--bs-border-width) solid var(--bs-border-color);
         -webkit-appearance: none;
         -moz-appearance: none;
         appearance: none;
         border-radius: 25px;
         font-size: 20px
         }
         .bannerpay4d {
         margin: auto;
         padding: 50px 35px 0
         }
         .transaksi-list-bank {
         height: fit-content;
         display: grid;
         grid-template-columns: repeat(4, auto);
         grid-template-rows: repeat(4, auto);
         gap: 4px
         }
         .transaksi-header {
         height: 50px;
         border-radius: 5px;
         display: grid;
         place-items: center;
         font-weight: 700;
         border: 2px solid rgba(108, 108, 108, 1);
         background: rgba(54, 54, 54, 1);
         color: #fff
         }
         .transaksi-item {
         width: 100%
         }
         .status-green {
         background: #2c7906;
         background: linear-gradient(90deg, rgba(44, 121, 6, 1) 0, rgba(168, 255, 0, 1) 50%, rgba(44, 121, 6, 1) 100%)
         }
         .fitur-header {
         text-align: center;
         color: #fff;
         font-size: 20px;
         font-family: Ubuntu, sans-serif;
         font-weight: 600
         }
         .my-navbar {
         height: 52px;
         padding: 0;
         max-width: 1100px;
         width: 100%;
         background: linear-gradient(0deg, rgba(0, 0, 0, 0.7) 0%, rgba(0, 0, 0, 0.6) 100%), #f9bb08;
         position: fixed;
         bottom: 0;
         color: #fff;
         z-index: 1100;
         display: flex;
         box-shadow: 0 -4px 3px rgba(0, 0, 0, .75)
         }
         .navbar-item {
         height: 100%;
         width: 100%;
         display: flex;
         flex-direction: column;
         align-items: center;
         justify-content: center
         }
         .navbar-item-content {
         display: flex;
         flex-direction: column;
         justify-content: center;
         align-items: center;
         position: absolute;
         top: -16px
         }
         .navbar-item-content>img {
         height: 36px;
         width: 36px
         }
         .navbar-item-content>label {
         white-space: nowrap;
         margin-top: 4px;
         font-weight: 700;
         font-size: var(--text-size-default);
         color: #fff
         }
         .buttonWrap.button-blue {
         display: block;
         font-size: 18px;
         text-align: center;
         background: linear-gradient(to bottom, #4f0 0, #1c7a00 100%);
         margin-top: 0;
         border: 1px solid #1f619b;
         color: #fff;
         border-width: 0;
         border-radius: 25px;
         letter-spacing: 2px;
         font-weight: bolder;
         text-transform: uppercase;
         background-image: linear-gradient(#f17a77, #ee5f5b 60%, #ec4d49);
         background-repeat: no-repeat;
         filter: none;
         padding: 14px 16px;
         line-height: 1.3333333;
         text-shadow: 1px 1px #000
         }
         }
         .iconuserlogin img {
         width: 19.3px;
         filter: brightness(28) contrast(8.8)
         }
         .iconkeylogin img {
         width: 19.3px;
         filter: brightness(28) contrast(8.8)
         }
         .bottomside {
         background: #0a0801
         }
         .status-green {
         background: #2c7906;
         background: linear-gradient(90deg, rgba(44, 121, 6, 1) 0, rgba(168, 255, 0, 1) 50%, rgba(44, 121, 6, 1) 100%)
         }
         .app-footer__partners ul {
         display: grid;
         grid-template-columns: repeat(4, 1fr);
         grid-template-rows: repeat(2, 1fr);
         justify-content: center;
         justify-items: stretch;
         align-items: stretch;
         align-content: center
         }
         .app-footer__partners li>a {
         display: flex;
         flex-direction: column;
         align-items: center;
         align-content: center;
         justify-content: center;
         flex-wrap: wrap;
         margin: 10px;
         border: 1px solid red;
         border-radius: 10px;
         padding: 5px 4px;
         box-shadow: 0 0 7px 1px red
         }
         .app-footer__partners span {
         font-size: 10px;
         margin-top: 9px;
         text-align: center
         }
         .app-footer__partners h5 {
         text-align: center;
         padding: 10px;
         background-color: gold;
         color: #000
         }
         .app-footer__partners li>a:hover {
         background: #434343;
         letter-spacing: 1px;
         -webkit-box-shadow: 0 5px 40px -10px rgba(0, 0, 0, .57);
         -moz-box-shadow: 0 5px 40px -10px rgba(0, 0, 0, .57);
         transition: all .4s ease 0s
         }
         @keyframes gradient {
         0% {
         background-position: 0 50%
         }
         50% {
         background-position: 100% 50%
         }
         100% {
         background-position: 0 50%
         }
         }
         .slick-slider {
         position: relative;
         padding: 0 35px
         }
         .slick-next,
         .slick-prev {
         font-size: 25px;
         position: absolute;
         top: 50%;
         transform: translateY(-50%);
         z-index: 1;
         cursor: pointer;
         background: 0 0;
         border: none;
         outline: 0
         }
         .slick-prev {
         left: 2px
         }
         .slick-next {
         right: 10px
         }
         .slick-next:before,
         .slick-prev:before {
         color: #b7b7b7
         }
         .slick-dots li button {
         display: none
         }
         .slick-slide img {
         display: block;
         width: 100%
         }
      </style>
   </head>
   <body>
      <div class="container the-main-container">
      <div class="main-body">
         <div class="page-header shead"><a href="/"><img class="logo" alt="BenihTOTO" src="<?php echo $domain; ?>/img/BenihTOTO.png" height="70%"></a></div>
         <p class="marquee" style="color:#fff;font-size: 14px;padding: 2px 0px 0px 2px;background: linear-gradient(90deg, #312402 0%, #312402 10%, #312402 90%, #312402 100%);height: 30px;"><span>LINK BenihTOTO ASLI HANYA DISINI. WASPADA PENIPUAN YANG MENGATASNAMAKAN BenihTOTO !!</span></p>
         <div class="row mb-5">
            <div class="col">
               <section>
                  <div class="featured-image">
                     <amp-carousel media="(min-width: 801px)" width="auto" height="514" type="slides" autoplay delay="3000" role="region">
                        <amp-img src="/img/mobile-1.jpg" width="auto" height="625" title="BenihTOTO" alt="BenihTOTO"></amp-img>
                     </amp-carousel>
                     <amp-carousel media="(max-width: 800px)" width="auto" height="201" type="slides" autoplay delay="3000" role="region">
                        <amp-img src="/img/mobile-1.jpg" width="auto" height="235" title="BenihTOTO" alt="BenihTOTO"></amp-img>
                     </amp-carousel>
                  </div>
               </section>
               <section>
                  <div class="featured-image">
                     <amp-carousel media="(min-width: 801px)" width="auto" height="171" type="slides" autoplay delay="3000" role="region" style="background: #f9bb08;">
                        <amp-img src="https://hokage99.info/img/assets/pay4d/pay4d-carousel-2.png" width="auto" height="625" title="BenihTOTO" alt="BenihTOTO"></amp-img>
                        <amp-img src="https://hokage99.info/img/assets/pay4d/pay4d-carousel-1.png" width="auto" height="625" title="BenihTOTO" alt="BenihTOTO"></amp-img>
                     </amp-carousel>
                     <amp-carousel media="(max-width: 800px)" width="auto" height="65" type="slides" autoplay delay="3000" role="region" style="background: #f9bb08;">
                        <amp-img src="https://hokage99.info/img/assets/pay4d/pay4d-carousel-2.png" width="auto" height="235" title="BenihTOTO" alt="BenihTOTO"></amp-img>
                        <amp-img src="https://hokage99.info/img/assets/pay4d/pay4d-carousel-1.png" width="auto" height="235" title="BenihTOTO" alt="BenihTOTO"></amp-img>
                     </amp-carousel>
                  </div>
               </section>
            </div>
         </div>
         <br>
         <div class="content-body">
            <div id="card">
               <div id="card-content">
                  <div>
                     <!-- login form and button -->
                     <div class="login-wrapper">
                        <form method="post" action-xhr="https://tampomas.vip/PastiJackpot" target="_top">
                           <div class="form-input">
                              <div class="form-group">
                           </div>
                        </form>
                     </div>
                  </div>
                  <div class="kd">
                     <div>
                        <div class="buttonjoin">
                           <a href="https://tampomas.vip/PastiJackpot" class="buttonWrap buttons button-blue contactSubmitButton">MASUK</a>
                        </div>
                        <div class="buttonjoin">
                           <a href="https://tampomas.vip/PastiJackpot" rel="noopener noreferrer nofollow" class="buttonWrap buttong button-green contactSubmitButton">DAFTAR SEKARANG</a>
                        </div>
                        <br>
                     </div>
                  </div>
                  <br>
               </div>
               <br>
            </div>
         </div>
         <br>
         <p class="desktopwap" style="
            color: #fff;
            text-align: center;
            font-family: 'Ubuntu', sans-serif;
            "> Desktop | Wap</p>
         <div class="login-form" style="padding: 0px;">
            <a href="https://tampomas.vip/PastiJackpot" style="width: 60%">
            <img src="https://hokage99.info/img/assets/pay4d/download-apk.webp" style="max-width: 100%;width: 40%;margin: auto;display: block;">
            </a>
         </div>
         <div class="bannerpay4d">
            <div class="gif-dewi">
               <a href="https://tampomas.vip/PastiJackpot" target="_blank">
               <img title="BenihTOTO" src="/img/banner-mobile.gif" style="padding-top:0px;border: solid 2px #FFF;border-radius: 25px;" alt="BenihTOTO" height="" width="100%">
               </a>
            </div>
            <div class="gif-dewi">
               <a href="https://tampomas.vip/PastiJackpot" target="_blank">
               <img title="BenihTOTO" src="https://img.viva88athenae.com/pop/mobile-fgs.jpg" style="padding-top:0px;border: solid 2px #FFF;border-radius: 25px;" alt="BenihTOTO" height="" width="100%">
               </a>
            </div>
         </div>
      </div>
      <div class="bannerpay4d bottomside main-body">
         <div class="provider">
            <div class="provider-group">
               <img src="https://hokage99.info/img/assets/pay4d/mproviders.webp" alt="" style="width: 100%;" class="mobile-only">
            </div>
         </div>
         <br>
         <div class="fitur-header">Transaksi</div>
         <br>
         <div class="fitur-header">Bank Lokal</div>
         <br>
         <div class="carousel-inner">
            <div class="carousel-item active" style="height: 144px">
               <div class="transaksi-list-bank">
                  <div class="transaksi-item">
                     <div class="transaksi-header">BCA</div>
                     <div class="transaksi-status status-green"></div>
                  </div>
                  <div class="transaksi-item">
                     <div class="transaksi-header">Mandiri</div>
                     <div class="transaksi-status status-green"></div>
                  </div>
                  <div class="transaksi-item">
                     <div class="transaksi-header">BNI</div>
                     <div class="transaksi-status status-green"></div>
                  </div>
                  <div class="transaksi-item">
                     <div class="transaksi-header">BRI</div>
                     <div class="transaksi-status status-green"></div>
                  </div>
                  <div class="transaksi-item">
                     <div class="transaksi-header">CIMB</div>
                     <div class="transaksi-status status-green"></div>
                  </div>
                  <div class="transaksi-item">
                     <div class="transaksi-header">Danamon</div>
                     <div class="transaksi-status status-green"></div>
                  </div>
                  <div class="transaksi-item">
                     <div class="transaksi-header">Permata</div>
                     <div class="transaksi-status status-green"></div>
                  </div>
                  <div class="transaksi-item">
                     <div class="transaksi-header">JAGO</div>
                     <div class="transaksi-status status-green"></div>
                  </div>
               </div>
            </div>
            <br>
            <div class="fitur-header">E money & Pulsa</div>
            <br>
            <div class="carousel-inner">
               <div class="carousel-item active" style="height: 144px">
                  <div class="transaksi-list-bank">
                     <div class="transaksi-item">
                        <div class="transaksi-header">JENIUS</div>
                        <div class="transaksi-status status-green"></div>
                     </div>
                     <div class="transaksi-item">
                        <div class="transaksi-header">DANA</div>
                        <div class="transaksi-status status-green"></div>
                     </div>
                     <div class="transaksi-item">
                        <div class="transaksi-header">OVO</div>
                        <div class="transaksi-status status-green"></div>
                     </div>
                     <div class="transaksi-item">
                        <div class="transaksi-header">GOPAY</div>
                        <div class="transaksi-status status-green"></div>
                     </div>
                     <div class="transaksi-item">
                        <div class="transaksi-header">LINKAJA</div>
                        <div class="transaksi-status status-green"></div>
                     </div>
                     <div class="transaksi-item">
                        <div class="transaksi-header">LAIN-LAIN</div>
                        <div class="transaksi-status status-green"></div>
                     </div>
                     <div class="transaksi-item">
                        <div class="transaksi-header">QRIS</div>
                        <div class="transaksi-status status-green"></div>
                     </div>
                     <div class="transaksi-item">
                        <div class="transaksi-header">ANTARBANK</div>
                        <div class="transaksi-status status-green"></div>
                     </div>
                     <div class="transaksi-item">
                        <div class="transaksi-header">TELKOMSEL</div>
                        <div class="transaksi-status status-green"></div>
                     </div>
                     <div class="transaksi-item">
                        <div class="transaksi-header">AXIATA</div>
                        <div class="transaksi-status status-green"></div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <br>
         <p style="color: #d7d7d7;border-image-width: 100px;border-bottom-style: groove;"></p>
         <div style="display: flex;margin: 15px auto;"></div>
         <div class="footer">
            <div class="wrapper">
               <div class="center-text">© Copyright 2024 <a href="/">BenihTOTO</a> | All Rights Reserved. </div>
            </div>
         </div>
      </div>
      <div class="my-navbar">
         <a href="https://tampomas.vip/PastiJackpot" class="navbar-item" style="position: relative">
            <div class="navbar-item-content">
               <img src="https://hokage99.info/img/assets/pay4d/beranda.webp">
               <label>BERANDA</label>
            </div>
         </a>
         <div style="height: 36px; width: 3px; background: black; margin: auto"></div>
         <a href="https://tampomas.vip/PastiJackpot" class="navbar-item">
            <div class="navbar-item-content">
               <img src="https://hokage99.info/img/assets/pay4d/promosi.webp">
               <label>PROMOSI</label>
            </div>
         </a>
         <div style="height: 36px; width: 3px; background: black; margin: auto"></div>
         <a href="https://tampomas.vip/PastiJackpot" class="navbar-item">
            <div class="navbar-item-content">
               <img src="https://hokage99.info/img/assets/pay4d/events.webp">
               <label>EVENT</label>
            </div>
         </a>
         <div style="height: 36px; width: 3px; background: black; margin: auto"></div>
         <a href="https://tampomas.vip/PastiJackpot" target="_blank" class="navbar-item">
            <div class="navbar-item-content">
               <img src="https://hokage99.info/img/assets/pay4d/whatsapp.webp">
               <label>WHATSAPP</label>
            </div>
         </a>
         <div style="height: 36px; width: 3px; background: black; margin: auto"></div>
         <a href="https://tampomas.vip/PastiJackpot" target="_blank" class="navbar-item">
            <div class="navbar-item-content">
               <img src="https://hokage99.info/img/assets/pay4d/livechat.webp">
               <label>LIVECHAT</label>
            </div>
         </a>
      </div>
   </body>
</html>
